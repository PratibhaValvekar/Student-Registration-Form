
import './App.css';
import Registrationform from './Component/Registrationform';
import RegistrationformDetails from './Component/RegistrationformDetails';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path={"/"} element={<Registrationform />} />
          <Route path={"/registrationformDetails"} element={<RegistrationformDetails />} />
          <Route path="/registrationform/:id" element={<Registrationform />} />
          <Route path={"/registrationformDetails/:id"} element={<Registrationform />} />


        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;
