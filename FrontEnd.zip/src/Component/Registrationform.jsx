import axios from 'axios';
import React, { useEffect, useState } from 'react';
import {useNavigate, useParams } from 'react-router-dom';

export default function Registrationform() {
    const { id } = useParams();

    const navigate = useNavigate();

    const [data, setData] = useState({
        firstName: "",
        middleName: "",
        lastName: "",
        birthdayDate: "",
        email: "",
        mobileNumber: "",
        addresses: [{ addressName: "" }],
        state: "",
        country: ""
    });

    const [formErrors, setFormErrors] = useState({});

    useEffect(() => {
        if (id) {
            axios.get(`http://localhost:8080/registration/${id}`)
                .then((res) => {
                    setData(res.data);
                });
        }
    }, [id]);

    function handleChange(e) {
        setData({ ...data, [e.target.id]: e.target.value });
    };

    function handleAddressChange(e, index) {
        const { value } = e.target;
        const updatedAddresses = [...data.addresses];
        updatedAddresses[index] = { addressName: value };
        setData({ ...data, addresses: updatedAddresses });
    }

    function addAddress() {
        setData({ ...data, addresses: [...data.addresses, { addressName: "" }] });
    }

    function removeAddress(index) {
        const updatedAddresses = [...data.addresses];
        updatedAddresses.splice(index, 1);
        setData({ ...data, addresses: updatedAddresses });
    }

    const validate = () => {
        const errors = {};
        if (!data.firstName) errors.firstName = "First Name is required!";
        if (!data.middleName) errors.middleName = "Middle Name is required!";
        if (!data.lastName) errors.lastName = "Last Name is required!";
        if (!data.birthdayDate) {
            errors.birthdayDate = "Birthday Date is required!";
        } else {
            const birthday = new Date(data.birthdayDate);
            const today = new Date();
            if (birthday >= today) {
                errors.birthdayDate = "Birthday Date must be in the past!";
            }
        }
        if (!data.email) {
            errors.email = "Email is required!";
        } else if (!/\S+@\S+\.\S+/.test(data.email)) {
            errors.email = "Email address is invalid!";
        }
        if (!data.mobileNumber) {
            errors.mobileNumber = "Mobile Number is required!";
        } else if (!/^[1-9]\d{9}$/.test(data.mobileNumber)) {  
            errors.mobileNumber = "Mobile Number must be 10 digits and cannot start with 0!";
        }
        if (!data.state) errors.state = "State is required!";
        if (!data.country) errors.country = "Country is required!";

        data.addresses.forEach((address, index) => {
            if (!address.addressName) {
                errors[`address_${index}`] = `Address ${index + 1} is required!`;
            }
        });

        return errors;
    };

    // Submit form
    function handleSubmit(e) {
        e.preventDefault();
        const errors = validate();
        if (Object.keys(errors).length) {
            setFormErrors(errors);
            return;
        }
        if (id === undefined) {
            axios.post("http://localhost:8080/registration/", data)
                .then((res) => {
                    console.log(res.data);
                    setData({
                        firstName: "",
                        middleName: "",
                        lastName: "",
                        birthdayDate: "",
                        email: "",
                        mobileNumber: "",
                        addresses: [{ address: "" }]
                    });
                    navigate("/registrationformDetails");
                });
        } else {
            axios.put("http://localhost:8080/registration/" + id, data)
                .then((res) => {
                    console.log(res.data);
                    navigate("/registrationformDetails");
                });
        }
    }

    useEffect(() => {
        if (id) {
            axios.get("http://localhost:8080/registration/" + id)
                .then((res) => {
                    setData(res.data);  
                });
        }
    }, [id]);

    return (
        <div>
            <section className="vh-500 gradient-custom">
                <div className="container py-5 h-100">
                    <div className="row justify-content-center align-items-center h-100">
                        <div className="col-12 col-lg-9 col-xl-8">
                            <div className="card shadow-2-strong card-registration gradient-custom-form" style={{ borderRadius: "15px" }}>
                                <div className="card-body p-4 p-md-">
                                    <h3 className="mb-4 pb-2 pb-md-0 mb-md-5">Registration Form</h3>
                                    <form onSubmit={handleSubmit}>
                                        <div className="row">
                                            <div className="col-md-4 mb-4">
                                                <div className="form-outline">
                                                    <label className="form-label">First Name</label>
                                                    <input type="text" value={data.firstName} id='firstName' onChange={handleChange} className="form-control form-control-lg" />
                                                    {formErrors.firstName && <p className='text-danger'>*{formErrors.firstName}</p>}
                                                </div>
                                            </div>

                                            <div className="col-md-4 mb-4">
                                                <div className="form-outline">
                                                    <label className="form-label">Middle Name</label>
                                                    <input type="text" value={data.middleName} id='middleName' onChange={handleChange} className="form-control form-control-lg" />
                                                    {formErrors.middleName && <p className='text-danger'>*{formErrors.middleName}</p>}
                                                </div>
                                            </div>

                                            <div className="col-md-4 mb-4">
                                                <div className="form-outline">
                                                    <label className="form-label">Last Name</label>
                                                    <input type="text" value={data.lastName} id='lastName' onChange={handleChange} className="form-control form-control-lg" />
                                                    {formErrors.lastName && <p className='text-danger'>*{formErrors.lastName}</p>}

                                                </div>
                                            </div>
                                        </div>

                                        <div className="row">
                                            <div className="col-md-6 mb-4">
                                                <div className="form-outline">
                                                    <label htmlFor="birthdayDate" className="form-label">Birthday Date</label>
                                                    <input type="date" value={data.birthdayDate} id='birthdayDate' onChange={handleChange} className="form-control form-control-lg" />
                                                    {formErrors.birthdayDate && <p className='text-danger'>*{formErrors.birthdayDate}</p>}
                                                </div>
                                            </div>
                                        </div>

                                        <div className="row">
                                            <div className="col-md-6 mb-4">
                                                <div className="form-outline">
                                                    <label className="form-label">Email</label>
                                                    <input type="email" value={data.email} id='email' onChange={handleChange} className="form-control form-control-lg" />
                                                    {formErrors.email && <p className='text-danger'>*{formErrors.email}</p>}
                                                </div>
                                            </div>

                                            <div className="col-md-6 mb-4">
                                                <div className="form-outline">
                                                    <label className="form-label">Mobile Number</label>
                                                    <input type="tel" value={data.mobileNumber} id='mobileNumber' onChange={handleChange} className="form-control form-control-lg" />
                                                    {formErrors.mobileNumber && <p className='text-danger'>*{formErrors.mobileNumber}</p>}
                                                </div>
                                            </div>



                                            <div className="row">
                                                <div className="col-md-6 mb-4">
                                                    <div className="form-outline">
                                                        <label className="form-label">State</label>
                                                        <input type="text" value={data.state} id='state' onChange={handleChange} className="form-control form-control-lg" />
                                                        {formErrors.state && <p className='text-danger'>*{formErrors.state}</p>}
                                                    </div>
                                                </div>

                                                <div className="col-md-6 mb-4">
                                                    <div className="form-outline">
                                                        <label className="form-label">Country</label>
                                                        <input type="text" value={data.country} id='country' onChange={handleChange} className="form-control form-control-lg" />
                                                        {formErrors.country && <p className='text-danger'>*{formErrors.country}</p>}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        {data.addresses.map((address, index) => (
                                            <div key={index}>
                                                <div className="row">
                                                    <div className="col-md-12 mb-4">
                                                        <label className="form-label">Address</label>
                                                        <textarea value={address.addressName} onChange={(e) => handleAddressChange(e, index)} className="form-control form-control-lg" />
                                                        {formErrors[`address_${index}`] && <p className='text-danger'>*{formErrors[`address_${index}`]}</p>}
                                                    </div>
                                                </div>

                                                {data.addresses.length > 1 && (
                                                    <button type="button" onClick={() => removeAddress(index)} className="btn btn-danger mb-3">Remove Address</button>
                                                )}
                                            </div>
                                        ))}

                                       
                                        <button type="button" onClick={addAddress} className="btn btn-secondary mb-3">Add Address</button>

                                        <div className="mt-4 pt-2">
                                            <input className="btn btn-primary btn-lg" type="submit" value="Submit" />
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
}
