import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

export default function RegistrationformDetails() {
    const [newData, setNewData] = useState([]);

    function loadData() {
        axios.get("http://localhost:8080/registration/")
            .then((res) => {
                console.log(res.data);
                setNewData(res.data);
            });
    }

    useEffect(() => {
        loadData();
    }, []);

    function handleDelete(id) {
        if (window.confirm("Are you sure...")) {
        axios.delete("http://localhost:8080/registration/" + id)
            .then((res) => {
                console.log(res.data);
                loadData();
            })
        }
    }

    return (
        <div>
            <section className="vh-500 gradient-custom">
                <div className="container py-5 h-100">
                    <div className="row justify-content-center align-items-center h-100">
                        <div className="col-12 col-lg-30 col-xl-40">
                            <div className="card shadow-2-strong card-registration gradient-custom-form" style={{ borderRadius: "15px" }}>
                                <div className="card-body p-4 p-md-">
                                    <table className="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">Id</th>
                                                <th scope="col">First Name</th>
                                                <th scope="col">Middle Name</th>
                                                <th scope="col">Last Name</th>
                                                <th scope="col">Birthday Date</th>
                                                <th scope="col">Email</th>
                                                <th scope="col">Mobile Number</th>
                                                <th scope="col">Addresses</th>
                                                <th scope="col">State</th>
                                                <th scope="col">Country</th>
                                                <th scope="col">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {newData.map((eachData, i) => (
                                                <tr key={eachData.studentId}>
                                                    <th scope="row">{i + 1}</th>
                                                    <td>{eachData.firstName}</td>
                                                    <td>{eachData.middleName}</td>
                                                    <td>{eachData.lastName}</td>
                                                    <td>{eachData.birthdayDate}</td>
                                                    <td>{eachData.email}</td>
                                                    <td>{eachData.mobileNumber}</td>
                                                    <td>
                                                        {eachData.addresses && eachData.addresses.length > 0 ? (
                                                            eachData.addresses.map((addressObj, index) => (
                                                                <p key={index}>{addressObj.addressName}</p>
                                                            ))
                                                        ) : (
                                                            <p>No Addresses</p>
                                                        )}
                                                    </td>
                                                    <td>{eachData.state}</td>
                                                    <td>{eachData.country}</td>
                                                    <td>
                                                        <Link to={`/registrationform/${eachData.studentId}`}>
                                                            <button type="button" className="btn btn-primary me-2"><i className="fa-solid fa-pencil"></i></button>
                                                            
                                                        </Link>
                                                        <button onClick={() => handleDelete(eachData.studentId)} type="button" className="btn btn-danger me-2"><i className="fa-solid fa-trash"></i></button>
                                                        
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
}
