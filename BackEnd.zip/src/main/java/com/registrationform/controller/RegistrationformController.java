package com.registrationform.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.registrationform.dto.RegistrationformDTO;
import com.registrationform.entity.Address;
import com.registrationform.entity.Registration;
import com.registrationform.service.AddressService;
import com.registrationform.service.RegistrationformService;

@RestController
@RequestMapping("/registration")
@CrossOrigin
public class RegistrationformController {
	@Autowired
	private RegistrationformService registrationformService;
	
@Autowired
	private AddressService addressService;

//	GetAll
	@GetMapping("/")
	public ResponseEntity<List<Registration>> getAllRegistrations() {
		List<Registration> reg = registrationformService.getAllRegistrations();
		return new ResponseEntity<>(reg,HttpStatus.OK);
	}
	
//	GetById
	@GetMapping("/{id}")
	public ResponseEntity<Registration> GetRegistrationById(@PathVariable Long id)
	{
		Registration reg = registrationformService.getRegistrationById(id);
		return new ResponseEntity<>(reg,HttpStatus.OK);
	}
	
	
//	Delete
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteRegistration(@PathVariable Long id)
	{
		registrationformService.deleteRegistration(id);
		return new ResponseEntity<Void> (HttpStatus.OK);
	}
	
	@PostMapping("/")	
    public ResponseEntity<Registration> saveRegistration(@RequestBody RegistrationformDTO registrationformDTO) {
        Registration rgst = new Registration();
      
        rgst.setFirstName(registrationformDTO.getFirstName());
        rgst.setMiddleName(registrationformDTO.getMiddleName());
        rgst.setLastName(registrationformDTO.getLastName());
        rgst.setBirthdayDate(registrationformDTO.getBirthdayDate());        
        rgst.setEmail(registrationformDTO.getEmail());
        rgst.setMobileNumber(registrationformDTO.getMobileNumber());
        rgst.setState(registrationformDTO.getState());
        rgst.setCountry(registrationformDTO.getCountry());
        rgst.setAddresses(registrationformDTO.getAddresses());

        Registration saveRegistration = registrationformService.saveRegistration(rgst);
        return new ResponseEntity<>(saveRegistration, HttpStatus.CREATED);
	}
	

	
	@PutMapping("/{id}")
	public ResponseEntity<Registration> updateRegistration(@PathVariable Long id, @RequestBody RegistrationformDTO registrationformDTO) {
	
	    Registration existingRegistration = registrationformService.getRegistrationById(id);
	    if (existingRegistration == null) {
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }
	 
	    existingRegistration.setFirstName(registrationformDTO.getFirstName());
	    existingRegistration.setMiddleName(registrationformDTO.getMiddleName());
	    existingRegistration.setLastName(registrationformDTO.getLastName());
	    existingRegistration.setBirthdayDate(registrationformDTO.getBirthdayDate());	    
	    existingRegistration.setEmail(registrationformDTO.getEmail());
	    existingRegistration.setMobileNumber(registrationformDTO.getMobileNumber());
	    existingRegistration.setState(registrationformDTO.getState());
	    existingRegistration.setCountry(registrationformDTO.getCountry());
   
	    List<Address> newAddresses = registrationformDTO.getAddresses();
	    List<Address> existingAddresses = existingRegistration.getAddresses();
	    
	    existingAddresses.clear();  

	    for (Address newAddress : newAddresses) {
	        Address address = new Address();
	        address.setAddressName(newAddress.getAddressName());
	       
	        existingAddresses.add(address);
	    }

	    Registration updatedRegistration = registrationformService.saveRegistration(existingRegistration);
	    return new ResponseEntity<>(updatedRegistration, HttpStatus.OK);
	}
}
