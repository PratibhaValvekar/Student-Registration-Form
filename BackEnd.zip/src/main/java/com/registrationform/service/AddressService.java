package com.registrationform.service;

import java.util.List;

import com.registrationform.entity.Address;
import com.registrationform.entity.Registration;

public interface AddressService {
	List<Address> getAllAddresss();

//	getByid
	public Address getAddressById(Long Id);
	
//	Delete
	public void deleteAddress(Long id);
	
//	post
	public Address Address(Address address);
}
