package com.registrationform.service;

import java.util.List;

import com.registrationform.entity.Registration;

public interface RegistrationformService {

	List<Registration> getAllRegistrations();

//	getByid
	public Registration getRegistrationById(Long Id);
	
//	Delete
	public void deleteRegistration(Long id);
	
//	post
	public Registration saveRegistration(Registration registration);
}
