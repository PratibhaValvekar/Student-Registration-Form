package com.registrationform.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.registrationform.entity.Registration;

@Repository
public interface RegistrationformRepository extends JpaRepository<Registration, Long> {

}
