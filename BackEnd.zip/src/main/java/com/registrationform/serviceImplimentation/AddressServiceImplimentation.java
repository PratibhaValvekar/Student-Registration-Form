package com.registrationform.serviceImplimentation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.registrationform.repository.AddressRepository;
import com.registrationform.service.AddressService;

@Service
public class AddressServiceImplimentation implements AddressService {
	
	@Autowired
	private AddressRepository addressRepository;

	@Override
	public List<com.registrationform.entity.Address> getAllAddresss() {
		
		return addressRepository.findAll();
	}

	@Override
	public com.registrationform.entity.Address getAddressById(Long Id) {
		
		return addressRepository.findById(Id).orElse(null);
	}

	@Override
	public com.registrationform.entity.Address Address(com.registrationform.entity.Address address) {
	
		return addressRepository.save(address);
	}

	@Override
	public void deleteAddress(Long id) {
		addressRepository.deleteById(id);
	}



}
