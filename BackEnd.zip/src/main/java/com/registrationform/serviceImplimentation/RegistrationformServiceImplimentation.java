package com.registrationform.serviceImplimentation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.registrationform.entity.Registration;
import com.registrationform.repository.RegistrationformRepository;
import com.registrationform.service.RegistrationformService;

@Service
public class RegistrationformServiceImplimentation implements RegistrationformService {
	
@Autowired
	private RegistrationformRepository registrationformRepository;

	@Override
	public List<Registration> getAllRegistrations() {
		
		return registrationformRepository.findAll();
	}

	@Override
	public Registration getRegistrationById(Long Id) {
		return registrationformRepository.findById(Id).orElse(null);
	}

	@Override
	public void deleteRegistration(Long id) {
		registrationformRepository.deleteById(id);
		
	}

	@Override
	public Registration saveRegistration(Registration registration) {
	
		return registrationformRepository.save(registration);
	}

	
}
