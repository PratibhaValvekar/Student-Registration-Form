package com.registrationform.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "addresses")
public class Address {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long addressId;

	private String addressName;

	public Address(Long addressId, String addressName) {
		super();
		this.addressId = addressId;
		this.addressName = addressName;
	}

	public Address() {
		
	}

	public Long getAddressId() {
		return addressId;
	}

	public void setAddressId(Long addressId) {
		this.addressId = addressId;
	}

	public String getAddressName() {
		return addressName;
	}

	public void setAddressName(String addressName) {
		this.addressName = addressName;
	}

	@Override
	public String toString() {
		return "AddressformEntity [addressId=" + addressId + ", addressName=" + addressName + "]";
	}
    
	
    
}
